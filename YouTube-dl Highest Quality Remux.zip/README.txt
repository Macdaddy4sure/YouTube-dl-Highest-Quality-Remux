 __     __      _______    _                    _ _   _____                           
 \ \   / /     |__   __|  | |                  | | | |  __ \                          
  \ \_/ /__  _   _| |_   _| |__   ___ ______ __| | | | |__) |___ _ __ ___  _   ___  __
   \   / _ \| | | | | | | | '_ \ / _ \______/ _` | | |  _  // _ \ '_ ` _ \| | | \ \/ /
    | | (_) | |_| | | |_| | |_) |  __/     | (_| | | | | \ \  __/ | | | | | |_| |>  < 
    |_|\___/ \__,_|_|\__,_|_.__/ \___|      \__,_|_| |_|  \_\___|_| |_| |_|\__,_/_/\_\
	
	by Macdaddy4sure
	
	Purpose: The following program cmobines YouTube-ld, FFMpeg and some extra scripts to remux less than best quality YouTube videos to hightest quality possible. Place less than high quallity YouTube videos into a watch folder. This program reads the watch directory, finds the id of a downloaded video, demux (takes out) the audio, prompt YouTube for the formats that can be downloaded, and finally muxes (or combines) the audio from the less than high quality video into a combined highest quality video stream and audio stream.
	
	Use:
		1. Extract the archive.
		2. Download FFMpeg from the following site: https://ffmpeg.org/download.html#build-windows
		3. Download YouTube-dl from the following site: https://ytdl-org.github.io/youtube-dl/download.html
		4. Where you extracted the archive, create a folder called Watch_Folder. This is the folder you will plcae videos into before they are remuxed.
		5. Create a folder called _Done. This is where the finished remuxed videos will be placed.
		6. Run the program.
		7. Press zero and then enter to run the Settings menu.
		8. Press one, then enter.
			a. Paste or enter the absolute path to where you installed YouTube-dl
			b. The program will validate if the executable exists.
		9. Press two, then enter.
			a. Paste or enter the absolute path for the watch_folder directory you createed earlier.
			b. The program will validate the directory.
		10. Enter three, then enter.
			a. Paste the absolute path for FFMpeg
			b. The program will evaluate wheather or not the ffmpeg.exe exists
		11. Enter five, then enter.
			a. Paste the path to the output folder.
			b. The program will validate whether or not the directory exists.
		12. Enter zero, then enter to go back to the main menu.
		13. At the main menu, enter one then enter to run the program
		14. Enter the number for the video you wantt to select.
		15. The program will start by demuxing the video or extract the audio into an uncompressed .wav
		16. The program will ask for you to enter a number to select the highest quality video stream. Enter the code on the left and press enter. The program will download the empty video stream.
		17. The program will then mux or combine the video and audio streams and save the output to the output folder.
		
		Done! Enjoy!
		Macdaddy4sure